from django.apps import AppConfig


class OrganizationConfig(AppConfig):
    name = "organization"
