from django.apps import AppConfig


class NewHireConfig(AppConfig):
    name = "new_hire"
