from django.apps import AppConfig


class PreboardingConfig(AppConfig):
    name = "admin.preboarding"
