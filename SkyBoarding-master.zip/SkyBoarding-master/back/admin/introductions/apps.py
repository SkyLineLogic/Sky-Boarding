from django.apps import AppConfig


class IntroductionsConfig(AppConfig):
    name = "admin.introductions"
