from django.apps import AppConfig


class SequencesConfig(AppConfig):
    name = "admin.sequences"
