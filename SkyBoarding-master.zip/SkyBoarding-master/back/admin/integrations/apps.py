from django.apps import AppConfig


class IntegrationsConfig(AppConfig):
    name = "admin.integrations"
