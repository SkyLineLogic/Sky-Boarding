from django.apps import AppConfig


class AdminTasksConfig(AppConfig):
    name = "admin.admin_tasks"
