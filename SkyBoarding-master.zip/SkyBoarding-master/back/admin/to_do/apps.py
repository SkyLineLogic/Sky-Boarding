from django.apps import AppConfig


class ToDoConfig(AppConfig):
    name = "admin.to_do"
