from django.apps import AppConfig


class AppointmentsConfig(AppConfig):
    name = "admin.appointments"
