from django.apps import AppConfig


class SlackBotConfig(AppConfig):
    name = "slack_bot"
