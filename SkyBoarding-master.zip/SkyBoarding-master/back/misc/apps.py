from django.apps import AppConfig


class MiscConfig(AppConfig):
    name = "misc"
